# KHIND Receipt OCR (FastAPI + PaddleOCR)

See README in previous message. Quick start:
1) `pip install -r requirements.txt`
2) `uvicorn app.main:app --reload`
3) Upload your raw CSV + images.zip (Image_X.* matching MLP_X).

Outputs (CSV + XLSX) appear under /outputs and are downloadable from the results page.
