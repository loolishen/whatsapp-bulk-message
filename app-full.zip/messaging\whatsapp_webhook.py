import json
import os
import sys
import re
import requests
from django.core.cache import cache
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt

_DIGITS_ONLY = re.compile(r"\D+")

def _p(*args):
    try:
        print(*args, file=sys.stderr)
    except Exception:
        pass

def _norm_number(n):
    if not n:
        return None
    s = str(n).strip()
    s = _DIGITS_ONLY.sub("", s)
    return s or None

def _safe_json(body_bytes):
    try:
        raw = body_bytes.decode("utf-8", errors="ignore") if body_bytes else ""
        return raw, (json.loads(raw) if raw.strip() else {})
    except Exception:
        return "", {}

def _echo_enabled() -> bool:
    """
    Legacy echo test switch.
    Keep disabled in production; the real bot replies are sent from services
    via `WhatsAppAPIService` using `WABOT_API_TOKEN`.
    """
    return os.getenv("WABOT_ENABLE_AUTOREPLY", "false").lower() == "true"

def _extract_from_and_text(obj):
    """
    Try multiple common shapes. We keep it flexible because wabot can wrap data.
    Handles WABot structure: key.remoteJid and message.conversation
    """
    if not isinstance(obj, dict):
        return None, ""

    # Common direct keys
    sender = obj.get("from") or obj.get("number") or obj.get("phone")
    
    # WABot structure: key.remoteJid contains sender (format: "60123456789@s.whatsapp.net")
    if not sender:
        key_obj = obj.get("key", {})
        if isinstance(key_obj, dict):
            remote_jid = key_obj.get("remoteJid", "")
            if remote_jid:
                # Remove @s.whatsapp.net suffix
                sender = remote_jid.split("@")[0] if "@" in remote_jid else remote_jid

    # Extract text - handle both string and object formats
    msg_obj = obj.get("message")
    text = ""
    
    if isinstance(msg_obj, dict):
        # WABot structure: message is an object with conversation or extendedTextMessage
        # Try conversation (simple text)
        text = msg_obj.get("conversation", "")
        # Try extendedTextMessage.text (longer messages)
        if not text:
            ext_text = msg_obj.get("extendedTextMessage", {})
            if isinstance(ext_text, dict):
                text = ext_text.get("text", "")
        # Fallback to body or text
        if not text:
            text = msg_obj.get("body") or msg_obj.get("text") or ""
    elif isinstance(msg_obj, str):
        # Direct string message
        text = msg_obj
    else:
        # Fallback to text field
        text = obj.get("text") or ""

    return _norm_number(sender), (str(text) if text is not None else "")

def _extract_message_meta(event_data):
    """
    Extract best-effort metadata (message id, fromMe, status) from WABot/Baileys payloads.
    """
    msg = None
    if isinstance(event_data, list) and event_data:
        msg = event_data[0] if isinstance(event_data[0], dict) else None
    elif isinstance(event_data, dict):
        msg = event_data

    if not isinstance(msg, dict):
        return {"msg_id": None, "from_me": None, "status": None, "remote_jid": None, "timestamp": None}

    key_obj = msg.get("key", {}) if isinstance(msg.get("key", {}), dict) else {}
    return {
        "msg_id": key_obj.get("id"),
        "from_me": key_obj.get("fromMe"),
        "remote_jid": key_obj.get("remoteJid"),
        "status": msg.get("status"),
        "timestamp": msg.get("messageTimestamp"),
    }

def _dedupe_key(sender, text, meta):
    """
    Build a short-lived idempotency key to prevent repeated WABot retries/events
    from re-processing the same inbound message.
    """
    if meta.get("msg_id"):
        return f"wabot:seen:msgid:{meta['msg_id']}"
    # fallback: remote+timestamp+text
    remote = meta.get("remote_jid") or sender or ""
    ts = meta.get("timestamp") or ""
    t = (text or "")[:200]
    return f"wabot:seen:fallback:{remote}:{ts}:{t}"

def _is_bot_message(msg_obj):
    """
    Check if a message is from the bot itself (outbound).
    WABot messages have key.fromMe = true for bot messages.
    """
    if not isinstance(msg_obj, dict):
        return False
    
    # Check if it's a list (messages.upsert format)
    if isinstance(msg_obj, list) and len(msg_obj) > 0:
        msg_obj = msg_obj[0]
    
    # Check key.fromMe field (WhatsApp Web protocol)
    key_obj = msg_obj.get("key", {})
    if isinstance(key_obj, dict):
        from_me = key_obj.get("fromMe", False)
        if from_me:
            return True
    
    # Also check top-level fromMe
    if msg_obj.get("fromMe", False):
        return True
    
    return False

def _process_incoming_message(sender: str, message_text: str):
    """
    Process incoming WhatsApp message through full contest flow.
    Uses lazy imports to avoid import-time failures.
    """
    if not sender or not message_text:
        return
    
    try:
        # Lazy imports to prevent import-time failures
        from django.utils import timezone
        from .models import Customer, CoreMessage, Conversation, WhatsAppConnection, Tenant
        
        # Get tenant first (required for Customer)
        tenant = Tenant.objects.first()
        if not tenant:
            _p("ERROR: No tenant found")
            return
        
        # Get or create customer
        clean_number = sender
        if not clean_number.startswith('60'):
            clean_number = '60' + clean_number
        
        customer, created = Customer.objects.get_or_create(
            tenant=tenant,
            phone_number=clean_number,
            defaults={
                'name': f'Customer {clean_number}',
                'address': '',
            }
        )
        
        if created:
            _p("Created new customer:", customer.phone_number)
        
        # Get tenant (first tenant for now)
        tenant = Tenant.objects.first()
        if not tenant:
            _p("ERROR: No tenant found")
            return
        
        # Get WhatsApp connection
        conn = WhatsAppConnection.objects.filter(tenant=tenant).first()
        if not conn:
            _p("ERROR: No WhatsApp connection found")
            return
        
        # Get or create conversation (handle MultipleObjectsReturned)
        conversation = Conversation.objects.filter(
            tenant=tenant,
            customer=customer,
            whatsapp_connection=conn
        ).order_by('-created_at').first()
        
        if not conversation:
            conversation = Conversation.objects.create(
                tenant=tenant,
                customer=customer,
                whatsapp_connection=conn
            )

        # If WABot forwards our outbound messages back to the webhook as "incoming",
        # we can detect it by matching the last outbound message in this conversation.
        try:
            recent_outbound = CoreMessage.objects.filter(
                conversation=conversation,
                direction="outbound",
            ).order_by("-created_at").first()
            if recent_outbound and (recent_outbound.text_body or "").strip() == (message_text or "").strip():
                # If it's very recent, treat as echo of our outbound and skip processing.
                age = timezone.now() - recent_outbound.created_at
                if age.total_seconds() < 180:
                    _p("SKIP: echoed outbound message forwarded to webhook")
                    return
        except Exception as e:
            _p("WARN: outbound-echo check failed:", str(e)[:200])
        
        # Create message record
        CoreMessage.objects.create(
            tenant=tenant,
            conversation=conversation,
            direction='inbound',
            status='delivered',
            text_body=message_text,
            provider_msg_id='',  # WABot doesn't provide message ID in webhook
            created_at=timezone.now()
        )
        
        # Process with PDPA service (lazy import)
        try:
            from .pdpa_service import PDPAConsentService
            pdpa_service = PDPAConsentService()
            pdpa_service.handle_incoming_message(customer, message_text, tenant)
        except Exception as e:
            _p("WARN: Error in PDPA service:", str(e)[:200])
        
        # Process step-by-step contest flow (lazy import)
        try:
            from .step_by_step_contest_service import StepByStepContestService
            step_contest_service = StepByStepContestService()
            contest_results = step_contest_service.process_message_for_contests(
                customer, message_text, tenant, conversation
            )
            if contest_results.get('flows_processed', 0) > 0:
                _p("Contest processing:", contest_results)
        except Exception as e:
            _p("WARN: Error in contest service:", str(e)[:200])
        
        _p("Processed message from", sender, ":", message_text[:50])
        
    except Exception as e:
        _p("ERROR processing message:", str(e)[:300])
        import traceback
        _p("Traceback:", traceback.format_exc()[:500])

@csrf_exempt
def whatsapp_webhook(request):
    if request.method == "GET":
        return JsonResponse({"status": "ok", "message": "webhook active"}, status=200)

    raw, top = _safe_json(request.body)

    ip = request.META.get("HTTP_X_FORWARDED_FOR", request.META.get("REMOTE_ADDR", "unknown"))
    ua = (request.META.get("HTTP_USER_AGENT", "unknown") or "")[:80]
    _p(f"WEBHOOK POST HIT path={request.path} IP={ip} UA={ua}")
    _p("TOP keys=", list(top.keys())[:10], "raw_len=", len(raw))

    # ---- Support BOTH formats ----
    # Format A: {"type":"message","data":{...}}
    event_type = top.get("type")
    event_data = top.get("data")

    # Format B (yours): {"instance_id": "...", "data": {"event": "...", "data": {...}}}
    instance_id = top.get("instance_id") or os.getenv("WABOT_INSTANCE_ID", "")
    if not event_type and isinstance(top.get("data"), dict):
        inner = top["data"]
        inner_event = inner.get("event")
        inner_data = inner.get("data")
        if inner_event:
            event_type = inner_event
            event_data = inner_data
        _p("INNER event=", inner_event, "INNER keys=", list(inner.keys())[:10])

    # Normalize message event names:
    # Some systems use "message", some "incoming_message", etc.
    # WABot uses "messages.upsert" for new messages
    event_str = str(event_type).lower() if event_type else ""
    is_message = event_str in {
        "message", "incoming_message", "messages", "message_received"
    } or event_str.startswith("messages.")

    # For messages.upsert, the actual message data might be nested differently
    # Log the structure to debug
    if isinstance(event_data, dict):
        _p("EVENT_DATA keys=", list(event_data.keys())[:20])
        _p("EVENT_DATA sample=", str(event_data)[:500])
    elif isinstance(event_data, list):
        _p("EVENT_DATA is list, len=", len(event_data))
        if event_data:
            _p("EVENT_DATA[0] keys=", list(event_data[0].keys())[:20] if isinstance(event_data[0], dict) else "not dict")
    
    sender, text = _extract_from_and_text(event_data if isinstance(event_data, dict) else {})
    _p("EVENT type=", event_type, "is_message=", is_message, "from=", sender, "text=", text[:200])

    meta = _extract_message_meta(event_data)
    _p("META msg_id=", meta.get("msg_id"), "fromMe=", meta.get("from_me"), "status=", meta.get("status"))

    # ---- Dedupe/idempotency to stop retries from causing loops ----
    if is_message and sender and text:
        key = _dedupe_key(sender, text, meta)
        # cache.add returns False if key already exists
        if not cache.add(key, True, timeout=120):
            _p("SKIP: duplicate message event (dedupe)", key)
            _p("WEBHOOK 200 OK (dedupe)")
            return JsonResponse({"status": "ok"}, status=200)

    # If inner data is nested again (sometimes event_data has {"data": {...}})
    if (not sender or not text) and isinstance(event_data, dict) and isinstance(event_data.get("data"), dict):
        sender2, text2 = _extract_from_and_text(event_data["data"])
        sender = sender or sender2
        text = text or text2
        _p("NESTED extract from=", sender, "text=", text[:200])
    
    # For messages.upsert, event_data might be a list of messages
    if (not sender or not text) and isinstance(event_data, list) and len(event_data) > 0:
        first_msg = event_data[0] if isinstance(event_data[0], dict) else {}
        sender2, text2 = _extract_from_and_text(first_msg)
        sender = sender or sender2
        text = text or text2
        _p("ARRAY extract from=", sender, "text=", text[:200])
    
    # Try extracting from common WABot message fields
    if (not sender or not text) and isinstance(event_data, dict):
        # WABot might use "key" -> "remoteJid" for sender, "message" -> "conversation" for text
        key_obj = event_data.get("key", {})
        if isinstance(key_obj, dict):
            remote_jid = key_obj.get("remoteJid", "")
            if remote_jid:
                sender = sender or _norm_number(remote_jid.replace("@s.whatsapp.net", ""))
        
        msg_obj = event_data.get("message", {})
        if isinstance(msg_obj, dict):
            conversation = msg_obj.get("conversation", "")
            if conversation:
                text = text or conversation
        _p("WABOT STRUCT extract from=", sender, "text=", text[:200])

    # ---- Check if message is from bot/outbound status (skip processing) ----
    # Some WABot setups forward outbound messages too; those will cause reply loops.
    is_bot_msg = (meta.get("from_me") is True)
    # Heuristic: Baileys includes `status` primarily for outbound messages.
    if meta.get("status") not in (None, 0, "0"):
        is_bot_msg = True
        _p("SKIP: message has status field (likely outbound)", meta.get("status"))
    if meta.get("from_me") is True:
        _p("SKIP: Message is from bot (fromMe=true), ignoring")
    
    if is_bot_msg:
        _p("WEBHOOK 200 OK (bot message skipped)")
        return JsonResponse({"status": "ok"}, status=200)
    
    # ---- Process incoming message ----
    if is_message and sender and text:
        # Process through full contest flow (PDPA, keywords, OCR, etc.)
        _process_incoming_message(sender, text)
    
    # ---- Optional echo reply for testing ----
    # Turn on with env var: WABOT_ENABLE_AUTOREPLY=true
    # Sends via `WhatsAppAPIService` to avoid needing a separate token name.
    if _echo_enabled() and sender and text:
        try:
            from .whatsapp_service import WhatsAppAPIService
            WhatsAppAPIService().send_text_message(sender, f"Echo: {text}")
        except Exception as e:
            _p("ECHO SEND ERROR:", str(e)[:200])

    _p("WEBHOOK 200 OK")
    return JsonResponse({"status": "ok"}, status=200)
