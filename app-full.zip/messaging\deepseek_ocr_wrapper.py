"""
DeepSeek OCR Wrapper for Django
Uses DeepSeek Vision API for receipt processing
"""
import logging
import os
import base64
import json
import tempfile
import requests
from pathlib import Path
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class DeepSeekOCRWrapper:
    """Wrapper for DeepSeek Vision API OCR"""
    
    def __init__(self):
        self.api_key = os.environ.get('DEEPSEEK_API_KEY')
        self.base_url = os.environ.get('DEEPSEEK_BASE_URL', 'https://api.deepseek.com')
        self.model = os.environ.get('DEEPSEEK_MODEL', 'deepseek-chat')
        self.available = bool(self.api_key)
        
        if not self.available:
            logger.warning("DeepSeek API key not found in environment")
    
    def process_receipt_image(
        self, 
        image_path: Path,
        fallback_city: Optional[str] = None,
        fallback_state: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process receipt image using DeepSeek Vision API
        
        Returns structured data:
        {
            'success': bool,
            'store_name': str,
            'store_location': str,
            'amount_spent': str,
            'products': [(name, qty), ...],
            'validity': 'VALID' | 'INVALID',
            'reason': str,
            'raw_text': str
        }
        """
        if not self.available:
            return self._error_response("DeepSeek API key not configured")
        
        try:
            # Read and encode image
            img_b64 = self._encode_image(image_path)
            
            # Get OCR text first
            ocr_text = self._extract_text(img_b64)
            
            if not ocr_text:
                return self._error_response("No text extracted from image")
            
            # Parse receipt structure
            parsed_data = self._parse_receipt_structure(img_b64, ocr_text)
            
            # Determine validity
            validity, reason = self._determine_validity(parsed_data)
            
            result = {
                'success': True,
                'store_name': parsed_data.get('store_name') or 'Unknown',
                'store_location': parsed_data.get('store_location') or f"{fallback_city}, {fallback_state}" if fallback_city else 'Unknown',
                'amount_spent': parsed_data.get('amount_spent') or '0.00',
                'products': parsed_data.get('items', []),
                'validity': validity,
                'reason': reason,
                'raw_text': ocr_text
            }
            
            logger.info(f"DeepSeek OCR processed: {result['store_name']}, {result['amount_spent']}")
            return result
            
        except Exception as e:
            logger.error(f"DeepSeek OCR failed: {e}", exc_info=True)
            return self._error_response(f"OCR processing error: {str(e)}")
    
    def _encode_image(self, image_path: Path) -> str:
        """Encode image to base64"""
        with open(image_path, 'rb') as f:
            return base64.b64encode(f.read()).decode('utf-8')
    
    def _extract_text(self, img_b64: str) -> str:
        """Extract raw text from receipt image"""
        try:
            from openai import OpenAI
            
            client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            
            prompt = (
                "Extract ALL visible text from this receipt image.\n"
                "Return the text line by line exactly as it appears.\n"
                "Focus on: store name, location, items, prices, and total amount."
            )
            
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an OCR system that extracts text from images."},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}
                            }
                        ]
                    }
                ],
                temperature=0.0
            )
            
            return response.choices[0].message.content or ""
            
        except Exception as e:
            logger.error(f"Text extraction failed: {e}", exc_info=True)
            return ""
    
    def _parse_receipt_structure(self, img_b64: str, ocr_text: str) -> Dict[str, Any]:
        """Parse receipt into structured JSON using vision API"""
        try:
            from openai import OpenAI
            
            client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            
            prompt = (
                "You are a strict receipt parser for Malaysian receipts.\n"
                "Parse this receipt and return ONLY valid JSON with this exact structure:\n"
                "{\n"
                '  "store_name": "string or null",\n'
                '  "store_location": "string with city/state or null",\n'
                '  "amount_spent": "RM123.45 format or null",\n'
                '  "items": [\n'
                '    {"name": "product name", "qty": 1},\n'
                '    {"name": "product name", "qty": 2}\n'
                '  ]\n'
                "}\n\n"
                "Rules:\n"
                "- Extract store_name from header (e.g., 'GUARDIAN', '7-ELEVEN', 'AEON')\n"
                "- Extract store_location (city/state/address)\n"
                "- Extract total amount_spent (look for TOTAL, GRAND TOTAL)\n"
                "- Extract all purchased items with quantities\n"
                "- Return ONLY the JSON, no explanations\n\n"
                f"OCR Text:\n{ocr_text[:2000]}"
            )
            
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You output only valid JSON."},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}
                            }
                        ]
                    }
                ],
                temperature=0.0
            )
            
            content = response.choices[0].message.content
            
            # Try to parse JSON from response
            try:
                # Sometimes the model wraps JSON in markdown code blocks
                if '```json' in content:
                    content = content.split('```json')[1].split('```')[0].strip()
                elif '```' in content:
                    content = content.split('```')[1].split('```')[0].strip()
                
                data = json.loads(content)
                
                # Normalize items format
                if 'items' in data and data['items']:
                    normalized_items = []
                    for item in data['items']:
                        if isinstance(item, dict):
                            name = item.get('name', '')
                            qty = item.get('qty', 1)
                            if name:
                                normalized_items.append((name, qty))
                    data['items'] = normalized_items
                
                return data
                
            except json.JSONDecodeError as e:
                logger.error(f"JSON parse error: {e}\nContent: {content}")
                return {}
            
        except Exception as e:
            logger.error(f"Receipt parsing failed: {e}", exc_info=True)
            return {}
    
    def _determine_validity(self, parsed_data: Dict[str, Any]) -> tuple[str, str]:
        """Determine if receipt is valid based on parsed data"""
        
        if not parsed_data:
            return 'INVALID', 'Failed to parse receipt data'
        
        # Check for required fields
        amount = parsed_data.get('amount_spent')
        store = parsed_data.get('store_name')
        items = parsed_data.get('items', [])
        
        if not amount or amount == 'null' or amount == '0.00':
            return 'INVALID', 'No purchase amount detected'
        
        if not store or store == 'null':
            return 'INVALID', 'Store name not detected'
        
        if not items or len(items) == 0:
            return 'INVALID', 'No items detected on receipt'
        
        # Check minimum amount (optional - adjust as needed)
        try:
            amount_num = float(amount.replace('RM', '').replace(',', '').strip())
            if amount_num < 1.0:
                return 'INVALID', f'Amount too low: {amount}'
        except (ValueError, AttributeError):
            return 'INVALID', f'Invalid amount format: {amount}'
        
        return 'VALID', 'Receipt validated successfully'
    
    def _error_response(self, error_msg: str) -> Dict[str, Any]:
        """Return standardized error response"""
        return {
            'success': False,
            'store_name': None,
            'store_location': None,
            'amount_spent': None,
            'products': [],
            'validity': 'INVALID',
            'reason': error_msg,
            'raw_text': ''
        }

